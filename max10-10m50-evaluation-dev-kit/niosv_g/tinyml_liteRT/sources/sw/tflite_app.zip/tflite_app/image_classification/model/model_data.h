#ifndef MODEL_DATA_H
#define MODEL_DATA_H

extern const unsigned char lenet_tflite[];
extern const unsigned int lenet_tflite_len;

#endif  // MODEL_DATA_H
